
TIPO_FAMILIA={
    HOMBRE:"hombre",
    MUJER:"mujer",
    PAREJA:"pareja",
    FAMILIA:"familia"
};
