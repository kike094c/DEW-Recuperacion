

var edificiosImportar=[{calle:"General Yagüe",numero:2,cp:"39001", plantas:[2,4,1]},
                    {calle:"Primero de Mayo",numero:1,cp:"39011", plantas:[1,1]},
                    {calle:"Paseo de Pereda",numero:5,cp:"39002", plantas:[2,2,1,1]}];                   
                        
  var inquilinosImportar=[{calle:"General Yagüe",numero:2,piso:3,puerta:1,nombre:"Gustavo Ramírez",genero:"hombre",miembros:5},
                          {calle:"General Yagüe",numero:2,piso:2,puerta:1,nombre:"María Pérez",genero:"hombre",miembros:1},
                          {calle:"General Yagüe",numero:2,piso:2,puerta:2,nombre:"Manuel González",genero:"hombre",miembros:1},
                          {calle:"General Yagüe",numero:2,piso:2,puerta:3,nombre:"Pepa Fernández",genero:"mujer",miembros:3},
                          {calle:"General Yagüe",numero:2,piso:1,puerta:1,nombre:"Asterio Gómez",genero:"hombre",miembros:2},                  
                          {calle:"Primero de Mayo",numero:1,piso:1,puerta:1,nombre:"Eleuterio Gómez",genero:"hombre",miembros:6}];
                            
           


